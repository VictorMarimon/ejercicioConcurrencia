class CuentaBancaria {
    private int saldo;

    public CuentaBancaria(int saldoInicial) {
        this.saldo = saldoInicial;
    }

    public synchronized void transferir(CuentaBancaria cuentaDestino, int monto) {
        if (saldo >= monto) {
            saldo -= monto;
            cuentaDestino.depositar(monto);
        }
    }

    public synchronized void depositar(int monto) {
        saldo += monto;
    }

    public synchronized int obtenerSaldo() {
        return saldo;
    }
}