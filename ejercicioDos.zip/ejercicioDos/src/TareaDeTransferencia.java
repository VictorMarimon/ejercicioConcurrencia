import java.util.Random;

class TareaDeTransferencia implements Runnable {
    private CuentaBancaria cuenta1;
    private CuentaBancaria cuenta2;

    public TareaDeTransferencia(CuentaBancaria cuenta1, CuentaBancaria cuenta2) {
        this.cuenta1 = cuenta1;
        this.cuenta2 = cuenta2;
    }

    @Override
    public void run() {
        Random random = new Random();
        for (int i = 0; i < 100; i++) {
            int monto = random.nextInt(200);
            if (random.nextBoolean()) {
                cuenta1.transferir(cuenta2, monto);
            } else {
                cuenta2.transferir(cuenta1, monto);
            }
        }
    }
}