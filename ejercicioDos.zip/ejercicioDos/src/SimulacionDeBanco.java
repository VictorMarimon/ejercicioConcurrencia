public class SimulacionDeBanco {
    public static void main(String[] args) {
        CuentaBancaria cuenta1 = new CuentaBancaria(1000);
        CuentaBancaria cuenta2 = new CuentaBancaria(1000);

        Thread hilo1 = new Thread(new TareaDeTransferencia(cuenta1, cuenta2));
        Thread hilo2 = new Thread(new TareaDeTransferencia(cuenta1, cuenta2));

        hilo1.start();
        hilo2.start();

        try {
            hilo1.join();
            hilo2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        int saldoTotal = cuenta1.obtenerSaldo() + cuenta2.obtenerSaldo();
        System.out.println("Saldo final de la cuenta 1: " + cuenta1.obtenerSaldo());
        System.out.println("Saldo final de la cuenta 2: " + cuenta2.obtenerSaldo());
        System.out.println("Saldo total: " + saldoTotal);
    }
}


