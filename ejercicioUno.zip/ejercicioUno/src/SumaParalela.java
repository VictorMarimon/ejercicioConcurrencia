import java.util.Arrays;

public class SumaParalela {
    public static void main(String[] args) {
        int[] arreglo = new int[1000];
        for (int i = 0; i < arreglo.length; i++) {
            arreglo[i] = i + 1;
        }

        int mitad = arreglo.length / 2;

        CalculadoraDeSuma calculadora1 = new CalculadoraDeSuma(arreglo, 0, mitad);
        CalculadoraDeSuma calculadora2 = new CalculadoraDeSuma(arreglo, mitad, arreglo.length);

        Thread hilo1 = new Thread(calculadora1);
        Thread hilo2 = new Thread(calculadora2);

        hilo1.start();
        hilo2.start();

        try {
            hilo1.join();
            hilo2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        int sumaTotal = calculadora1.obtenerSumaParcial() + calculadora2.obtenerSumaParcial();
        System.out.println("Suma total: " + sumaTotal);
    }
}
