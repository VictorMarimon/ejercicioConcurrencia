import java.util.Arrays;

class CalculadoraDeSuma implements Runnable {
    private int[] arreglo;
    private int inicio;
    private int fin;
    private int sumaParcial;

    public CalculadoraDeSuma(int[] arreglo, int inicio, int fin) {
        this.arreglo = arreglo;
        this.inicio = inicio;
        this.fin = fin;
    }

    @Override
    public void run() {
        sumaParcial = Arrays.stream(arreglo, inicio, fin).sum();
        System.out.println("Suma parcial desde " + inicio + " hasta " + (fin - 1) + ": " + sumaParcial);
    }

    public int obtenerSumaParcial() {
        return sumaParcial;
    }
}